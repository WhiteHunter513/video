# Flexbox Carousel Autoscroll

A Pen created on CodePen.io. Original URL: [https://codepen.io/WhiteHunter-513/pen/KKbYLgZ](https://codepen.io/WhiteHunter-513/pen/KKbYLgZ).

Based on Nick Walsh's flexbox carousel